package d1servicediscovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class D1ServiceDiscoveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
